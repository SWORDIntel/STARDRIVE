# How to get an EDID file
```
cp /sys/class/drm/card0-eDP-1/edid edid.bin
```